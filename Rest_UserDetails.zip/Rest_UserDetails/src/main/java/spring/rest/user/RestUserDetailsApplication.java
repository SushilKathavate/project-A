package spring.rest.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"user_api","spring"})
@EnableJpaRepositories(basePackages = {"user_api"})
@EntityScan(basePackages = {"user_api"})
public class RestUserDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestUserDetailsApplication.class, args);
	}

}
