package user_api.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import user_api.entity.User;
import user_api.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepositoryRef;
	
	public List<User> getAllUsers(){
		return userRepositoryRef.findAll();
	}
	
	public User getUserById(int id) {
		Optional<User> optionalUser=userRepositoryRef.findById(id);
		return optionalUser.orElse(null);
	}
	
	public User createUser(User user) {
		return userRepositoryRef.save(user);
	}
	
	public User updateUser(int id, User userDetails) {
		Optional<User> optionalUser=userRepositoryRef.findById(id);
		if(optionalUser.isPresent()) {
			User user=optionalUser.get();
			user.setName(userDetails.getName());
			user.setPassword(userDetails.getPassword());
			user.setEmail(userDetails.getEmail());
			return userRepositoryRef.save(user);
		}else {
			return null;
		}
	}
	
	public void deleteUser(int id) {
		userRepositoryRef.deleteById(id);
	}
}
