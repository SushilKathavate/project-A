package user_api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import user_api.entity.User;
import user_api.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userServiceRef;
	
	@GetMapping("/user_api")
	public ResponseEntity<List<User>> getAllUsers(){
		List<User> users=userServiceRef.getAllUsers();
		return new ResponseEntity<>(users,HttpStatus.OK);
	}
	
	@GetMapping("/user_api/{id}")
	public ResponseEntity<User> getUserById(@PathVariable int id){
		User user=userServiceRef.getUserById(id);
		if(user!=null) {
			return new ResponseEntity<>(user,HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/user_api")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userServiceRef.createUser(user);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    @PutMapping("/user_api/{id}")
    public ResponseEntity<User> updateUser(@PathVariable int id, @RequestBody User userDetails) {
        User updatedUser = userServiceRef.updateUser(id, userDetails);
        if (updatedUser != null) {
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/user_api/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable int id) {
        userServiceRef.deleteUser(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
	
}
