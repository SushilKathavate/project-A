package user_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import user_api.entity.User;

public interface UserRepository extends JpaRepository<User, Integer>{

}
